import unittest
from types import SimpleNamespace

from main import AutoJJSApp


class JJSOrderTests(unittest.TestCase):
    def test_number_first_order(self):
        app = SimpleNamespace(
            jjs_word1="SENTINELA",
            jjs_word2="AGUARDANDO",
            jjs_sequence_order="number_first",
            exclamation_format="junta",
            numero_para_extenso=lambda n: "UM",
        )

        self.assertEqual(
            AutoJJSApp._build_jjs_sequence(app, 1),
            ["UM!", "SENTINELA", "AGUARDANDO"],
        )

    def test_word_first_order(self):
        app = SimpleNamespace(
            jjs_word1="SENTINELA",
            jjs_word2="AGUARDANDO",
            jjs_sequence_order="word_first",
            exclamation_format="junta",
            numero_para_extenso=lambda n: "UM",
        )

        self.assertEqual(
            AutoJJSApp._build_jjs_sequence(app, 1),
            ["SENTINELA", "UM!", "AGUARDANDO"],
        )

    def test_jjs_does_not_stop_on_single_failed_confirmation(self):
        app = AutoJJSApp.__new__(AutoJJSApp)
        app.sequence_active = True
        app.typing_automatically = False
        app.is_typing_char = False
        app.jjs_delay_ms = 0
        app.jjs_auto_send_enter = True
        app.auto_typer = SimpleNamespace(
            is_discord_active=lambda: True,
            clear_textbox=lambda: None,
            fail_count=0,
            check_message_sent=lambda: False,
        )
        app.keyboard_controller = SimpleNamespace(
            type=lambda *args, **kwargs: None,
            press=lambda *args, **kwargs: None,
            release=lambda *args, **kwargs: None,
        )
        app.after = lambda *args, **kwargs: None

        result = app._jjs_type_and_send("TESTE")

        self.assertTrue(result)
        self.assertTrue(app.sequence_active)

    def test_jjs_stops_after_repeated_failed_confirmation(self):
        app = AutoJJSApp.__new__(AutoJJSApp)
        app.sequence_active = True
        app.typing_automatically = False
        app.is_typing_char = False
        app.jjs_delay_ms = 0
        app.jjs_auto_send_enter = True
        calls = {"count": 0}

        def fake_check_message_sent():
            calls["count"] += 1
            return False

        app.auto_typer = SimpleNamespace(
            is_discord_active=lambda: True,
            clear_textbox=lambda: None,
            fail_count=1,
            check_message_sent=fake_check_message_sent,
        )
        app.keyboard_controller = SimpleNamespace(
            type=lambda *args, **kwargs: None,
            press=lambda *args, **kwargs: None,
            release=lambda *args, **kwargs: None,
        )
        app.after = lambda *args, **kwargs: None

        result = app._jjs_type_and_send("TESTE")

        self.assertFalse(result)
        self.assertFalse(app.sequence_active)


if __name__ == "__main__":
    unittest.main()
